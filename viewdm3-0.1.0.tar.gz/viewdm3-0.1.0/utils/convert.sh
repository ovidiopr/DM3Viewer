pyuic4 DM3Viewer.ui -o ui_DM3Viewer.py
pyuic4 utils/Options.ui -o utils/ui_Options.py
pyrcc4 DM3Viewer.qrc -o DM3Viewer_rc.py
